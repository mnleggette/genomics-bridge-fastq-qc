# Sequencing Data Quality Assessment | Genomics Bridge 01

**Project type:** Self-directed bioinformatics training · **Platform:** Galaxy · **Software:** FastQC 0.12.1

## Research question

What quality issues are present in the raw sequencing reads from the `female_oral2.fastq-4143.gz` sample used in the Galaxy Training Network quality-control tutorial, and what should be investigated before downstream microbial analysis?

## Dataset and method

- **Sample:** `female_oral2.fastq-4143.gz` (snake oral microbiome tutorial dataset). Biological context is based on the tutorial, not inferred from the sequence alone.
- **Source:** Galaxy Training Network, [Quality Control tutorial](https://training.galaxyproject.org/training-material/topics/sequence-analysis/tutorials/quality-control/tutorial.html). Dataset hosted at [Zenodo record 3977236](https://zenodo.org/records/3977236).
- **Analysis:** Imported compressed FASTQ into [Galaxy USA](https://usegalaxy.org/), ran FastQC with default settings, and inspected HTML report and raw FastQC output. No trimming or filtering was performed.
- **Reproducibility:** Original FastQC HTML, raw results and summary are supplied in `fastqc_outputs/`.

## Basic statistics

| Metric | FastQC result |
|---|---:|
| Total sequences | 812 |
| Total bases | 240.3 kbp |
| Read length | 296 bases |
| GC content | 44% |
| Sequences flagged as poor quality | 0 |
| Quality encoding | Sanger / Illumina 1.9 |

**Important:** “0 sequences flagged as poor quality” is a field in FastQC basic statistics; it does *not* mean all bases or reads passed all QC modules.

## Findings

### 1. Per-base sequence quality — FAIL

Per-base mean Phred quality was **Q37.72 at base 1**, remained about **Q36.71 at bases 100–104**, then dropped to **Q29.56 at bases 105–109** and **Q15.61 at bases 295–296**. Read-end deterioration and increasing variability suggest that some later base calls may be unreliable. This does not imply every read has uniformly low quality.

![Per-base quality](figures/per_base_quality.png)

### 2. Per-sequence quality scores — WARNING

The mean-read-quality distribution is **bimodal**, with major peaks at **Q21 (236 reads)** and **Q37 (141 reads)**; another **136 reads are at Q20**. An earlier informal visual estimate of a single Q30–Q34 peak was incorrect. This split warrants consideration of distinct quality subpopulations, without assigning a cause on FastQC evidence alone.

![Per-sequence quality](figures/per_sequence_quality.png)

### 3. Adapter Content — FAIL

The adapter module detects a **Nextera Transposase Sequence signal reaching 54.56%** and **poly-A reaching 47.54%** at later reported positions. **Poly-G and the three listed Illumina adapter categories remain at 0%** in the recorded table. The Nextera-associated signal is a recognized adapter-category match, but the FastQC report alone does not establish its experimental origin or the best trimming parameters. Earlier visual labeling of this plot as poly-A plus poly-G was incorrect and was corrected against raw FastQC data.

![Adapter content](figures/adapter_content.png)

### 4. Additional QC checks

The report also flags **per-base sequence content (FAIL), per-sequence GC content (FAIL), sequence duplication levels (FAIL), and overrepresented sequences (FAIL)**. **Per-tile sequence quality is WARNING**. The duplication summary lists a **36.82% estimated deduplicated fraction** (per FastQC's method). An overrepresented prefix beginning `GTGTCAGCCGCCGCGG...` occurs in 46 reads (5.67%); the FastQC Possible Source field is `No Hit`. In targeted amplicon/microbiome workflows, unusual composition and duplication can sometimes be expected, so these flags require protocol-aware interpretation.

![Sequence duplication](figures/duplication_levels.png)

## Conclusion and next steps

This initial untrimmed dataset shows substantial late-cycle loss of base-call quality plus Nextera-associated sequence detection and poly-A signal. **Do not treat the reads as unequivocally ready for biological inference without reviewing the sequencing/library-preparation protocol.** Examine whether primer/adapter trimming and quality-based trimming or filtering are appropriate; document settings, rerun FastQC after any preprocessing, compare retained read lengths and QC metrics, and only then proceed to microbial classification or other downstream analysis.

## Limitations

Single input dataset; 812 reads. The analysis uses FastQC summary metrics and graphs only, without independent taxonomic assignment, known experimental metadata verification, or before/after trimming comparison. Module failures indicate QC flags rather than proof that all reads are unusable. No claim is made about the identities of organisms in the sample.

## Teach-back video outline (5–7 minutes)

1. **Question:** “Before studying the snake oral microbiome, can I trust the sequencing reads?”
2. **FASTQ discovery:** Explain four-line records and why `G` in the quality line is encoded Q38 rather than guanine.
3. **Prediction and first test:** Show per-base Q falling toward read ends.
4. **Unexpected finding:** Contrast the two mean-read-quality peaks (Q21 and Q37).
5. **Research correction:** Explain how raw data corrected the mistaken poly-G interpretation to **Nextera transposase + poly-A**. Treat verification as a positive scientific practice.
6. **Decision:** Discuss why trimming requires protocol review and a follow-up QC comparison.

## Repository contents

- `README.md` — documented analysis and discussion
- `figures/` — selected unaltered FastQC figures
- `fastqc_outputs/` — downloaded HTML report, raw QC results and module summary

*This is an educational analysis, not a claim of experimentally validated species identification.*
